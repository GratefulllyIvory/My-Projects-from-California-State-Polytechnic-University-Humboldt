--quiz.sql
CREATE TABLE quizResponse

(
wolfq BOOL,
oceanq BOOL,
alaskaq varchar(25),
);
