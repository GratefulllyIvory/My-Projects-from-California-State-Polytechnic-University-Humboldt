
--ArchitectBuyerForm.sql

CREATE TABLE ArchitectBuyerForm(
firstN varchar(10),
lastN varchar(16),
email varchar(20),
telephone integer,
descript varchar(20),
budget integer, 
timestamp TIMESTAMP
);
